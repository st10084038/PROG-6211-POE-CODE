﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Calculation
{
    class Program
    {
        delegate void Del(string str);
        static void Main(string[] args)
        {
            float grossIncome = 0;
            float taxDeducted = 0;
            float groceries = 0;
            float waterAndLights = 0;
            float travelCosts = 0;
            float cellPhone = 0;
            float otherexpen = 0;
            float monthlyRental = 0;
            float propertyPrice = 0;
            float totalDeposit = 0;
            float interestRate = 0;
            int monthrepay = 0;
            int typeAcc = 0;
            float eMI = 0;
            Dictionary<string, float> expenselist = new Dictionary<string, float>();//generic collection to store the expenses
            Console.WriteLine("Gross monthly income");
            float.TryParse(Console.ReadLine(), out grossIncome);
            Console.WriteLine("Estimated monthly tax deducted");
            float.TryParse(Console.ReadLine(), out taxDeducted);
            expenselist.Add("Estimated monthly tax deducted", taxDeducted);
            Console.WriteLine("Estimated monthly expenditures in each of the following categories");
            Console.WriteLine("Groceries");
            float.TryParse(Console.ReadLine(), out groceries);
            expenselist.Add("Groceries", groceries);
            Console.WriteLine("Water and lights");
            float.TryParse(Console.ReadLine(), out waterAndLights);
            expenselist.Add("Water and lights", waterAndLights);
            Console.WriteLine("Travel costs (including petrol)");
            float.TryParse(Console.ReadLine(), out travelCosts);
            expenselist.Add("Travel costs (including petrol)", travelCosts);
            Console.WriteLine("Cell phone and telephone");
            float.TryParse(Console.ReadLine(), out cellPhone);
            expenselist.Add("Cell phone and telephone", cellPhone);
            Console.WriteLine("Other expenses");
            float.TryParse(Console.ReadLine(), out otherexpen);
            expenselist.Add("Other expenses", otherexpen);
            Console.WriteLine("For Renting accommodation select 1 or select 2 for buying a property");
            Console.WriteLine("1. Renting accommodation");
            Console.WriteLine("2. Buying a property");
            typeAcc = Convert.ToInt32(Console.ReadLine());
            if (typeAcc == 1)
            {
                Console.WriteLine("Monthly rental amount");
                float.TryParse(Console.ReadLine(), out monthlyRental);
                expenselist.Add("Monthly rental amount", monthlyRental);
            }
            else if (typeAcc == 2)
            {
                Console.WriteLine("Purchase price of property");
                float.TryParse(Console.ReadLine(), out propertyPrice);
                Console.WriteLine("Total deposit");
                float.TryParse(Console.ReadLine(), out totalDeposit);
                Console.WriteLine("Interest rate (percentage)");
                float.TryParse(Console.ReadLine(), out interestRate);
                Console.WriteLine("Number of months to repay (between 240 and 360)");
                monthrepay = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Monthly home loan repayment for buying a property");
                eMI = emi_calculator(propertyPrice - totalDeposit, interestRate, monthrepay / 12);
                if (eMI > grossIncome / 3)
                {
                    Console.WriteLine("Approval of the home loan is unlikely");
                }
                expenselist.Add("Home Loan EMI", eMI);
            }
            float availableMoney = 0;
            if (typeAcc == 1)
            {
                availableMoney = grossIncome - (taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + monthlyRental);

            }
            else if (typeAcc == 2)
            {
                availableMoney = grossIncome - (taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + eMI);
            }
            Console.WriteLine("Available monthly money after all the specified deductions have been made:{0}", availableMoney);
            float emiveh = BuyVehicle();
            if (emiveh > 0)
            {
                expenselist.Add("Vehicle EMI", emiveh);
            }
            float totalExpense = 0;
            if (typeAcc == 1)
            {
                totalExpense = taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + monthlyRental + otherexpen + emiveh;
            }
            else if (typeAcc == 2)
            {
                totalExpense = taxDeducted + groceries + waterAndLights + travelCosts + cellPhone + otherexpen + eMI + emiveh;
            }
            if (totalExpense > (grossIncome * 3 / 4))
            {

                Del del3 = delegate (string name)
                { Console.WriteLine("Total expenses are greater than 75 percent of gross income"); };
            }
            //Display the expenses to the user in descending order by value
            Console.WriteLine("Expenses to the user in descending order by value");
            foreach (KeyValuePair<string, float> expin in expenselist.OrderBy(key => key.Value))
            {
                Console.WriteLine(expin.Key + expin.Value);
            }
            Console.ReadLine();
        }
        static float emi_calculator(float p, float r, float t)
        {
            float emi;
            r = r / (12 * 100); // one month interest
            t = t * 12; // one month period
            emi = (p * r * (float)Math.Pow(1 + r, t))
            / (float)(Math.Pow(1 + r, t) - 1);
            return (emi);
        }
        static float BuyVehicle()
        {
            Console.WriteLine("Want to buy a vehicle, select 1 or 2");
            Console.WriteLine("1: Yes");
            Console.WriteLine("2: No");
            float emivechilce = 0;
            int selectvehicle = Convert.ToInt32(Console.ReadLine());
            if (selectvehicle == 1)
            {
                Console.WriteLine("Model and make");
                string make = Console.ReadLine();
                Console.WriteLine("Purchase price");
                float purchasePrice = 0;
                float.TryParse(Console.ReadLine(), out purchasePrice);
                Console.WriteLine("Total deposit");
                float totalDeposit = 0;
                float.TryParse(Console.ReadLine(), out totalDeposit);
                Console.WriteLine("Interest rate (percentage)");
                float interestRate = 0;
                float.TryParse(Console.ReadLine(), out interestRate);
                Console.WriteLine("Estimated insurance premium");
                float estInsPremium = 0;
                float.TryParse(Console.ReadLine(), out estInsPremium);
                emivechilce = emi_calculator(purchasePrice - totalDeposit + estInsPremium, interestRate, 5);
            }
            return emivechilce;
        }

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace chegg_savingsqu
    {
        public partial class chegg_savings : System.Web.UI.Page
        {
            protected void Page_Load(object sender, EventArgs e)
            {

            }

            protected void Button1_Click(object sender, EventArgs e)
            {
                double total = Convert.ToDouble(txtgoal.Text);
                double year = Convert.ToDouble(txtyr.Text);
                double month = Convert.ToDouble(txtmon.Text);
                month = month / 12;
                year = year + month;
                double rate = Convert.ToDouble(txtrate.Text);
                rate = rate / 100;
                double result = total / ((Math.Pow((1 + (rate / 12)), (12 * year)) + ((Math.Pow((1 + (rate / 12)), (12 * year)) - 1) / (rate / 12))));
                txtresult.Text = result.ToString();
                txtgoal.Text = "";
                txtmon.Text = "";
                txtrate.Text = "";
                txtyr.Text = "";
            }
        }
    }


